
int main()
{
	char a[] = "test";

	PrintStop(a);
}
