void sort_from_lib(int list[], int size);

void load_library(char *library_name);

void unload_library();