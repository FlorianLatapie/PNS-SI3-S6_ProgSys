#ifndef _SORT_H_
#define _SORT_H_

void sort(int list[], int size);

#endif